import '../scss/main.scss';

document.addEventListener('DOMContentLoaded', function() {

    /* Mobile Navigation */
    function collapseMobileMenu() {
        const mobilemenuPanel = document.getElementById('mobileMenuPanel');
        mobilemenuPanel.classList.toggle('active');
        if (mobilemenuPanel.classList.contains('active')) {
            setTimeout(() => {
                mobilemenuPanel.classList.add('shown');
            }, 500);
        } else {
            mobilemenuPanel.classList.remove('shown');
        }
    }

    const mobileMenuTriggerEl = document.querySelector('[aria-controls="navigationMobile-menu"]');
    mobileMenuTriggerEl.addEventListener('click', collapseMobileMenu);
});
